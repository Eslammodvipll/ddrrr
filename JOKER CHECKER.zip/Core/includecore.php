<?php

include 'core.php';
include 'functions.php';

?>