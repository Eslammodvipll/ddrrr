<?php

$welcomecmd = '<b>Hi, '.$firstname.' [ '.$userId.' ]%0AWhat would you like to checkout first ?</b>';


$cmdtext = '<b>Here is the list of available commands. Select any button below</b>';

$newmember = "Hey there,$firstname%0AWelcome to $chatname";

?>